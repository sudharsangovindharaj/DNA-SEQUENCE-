"""
Unit test and verification script for the DNA pattern classification pipeline.
"""
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier

# Re-implement or import the core logic
DEFAULT_ASSIGNMENT_DATA = [
    {"Seq_ID": "S1", "Sequence": "ATGCGATC", "Group": "Group A"},
    {"Seq_ID": "S2", "Sequence": "ATGCGTAC", "Group": "Group A"},
    {"Seq_ID": "S3", "Sequence": "GCGCGTAT", "Group": "Group B"},
    {"Seq_ID": "S4", "Sequence": "GCGCGCGC", "Group": "Group B"},
]

FEATURE_COLS = ["Count_A", "Count_T", "Count_G", "Count_C", "Length", "GC_Content_Pct"]

def sanitize_sequence(seq: str) -> str:
    return "".join(seq.split()).upper()

def validate_dna(seq: str):
    if not seq:
        return False, "Sequence cannot be empty."
    valid_bases = set("ACGT")
    seq_bases = set(seq)
    invalid = seq_bases - valid_bases
    if invalid:
        return False, f"Invalid nucleotide characters detected: {', '.join(sorted(invalid))}."
    return True, "Valid DNA sequence."

def extract_features(sequence: str):
    seq = sanitize_sequence(sequence)
    length = len(seq)
    count_a = seq.count("A")
    count_t = seq.count("T")
    count_g = seq.count("G")
    count_c = seq.count("C")
    gc_content_pct = ((count_g + count_c) / length * 100.0) if length > 0 else 0.0
    return {
        "Count_A": int(count_a),
        "Count_T": int(count_t),
        "Count_G": int(count_g),
        "Count_C": int(count_c),
        "Length": int(length),
        "GC_Content_Pct": round(gc_content_pct, 2),
    }

def test_pipeline():
    # 1. Test Feature Extraction on S1..S4
    records = []
    for item in DEFAULT_ASSIGNMENT_DATA:
        f = extract_features(item["Sequence"])
        records.append({**item, **f})
    df = pd.DataFrame(records)
    print("Feature Table:")
    print(df[FEATURE_COLS + ["Seq_ID", "Group"]])

    # Assertions on S1: ATGCGATC -> A:2, T:2, G:2, C:2, L:8, GC%: 50.0%
    s1 = df[df["Seq_ID"] == "S1"].iloc[0]
    assert s1["Count_A"] == 2
    assert s1["Count_T"] == 2
    assert s1["Count_G"] == 2
    assert s1["Count_C"] == 2
    assert s1["Length"] == 8
    assert s1["GC_Content_Pct"] == 50.0

    # Assertions on S4: GCGCGCGC -> A:0, T:0, G:4, C:4, L:8, GC%: 100.0%
    s4 = df[df["Seq_ID"] == "S4"].iloc[0]
    assert s4["Count_A"] == 0
    assert s4["Count_T"] == 0
    assert s4["Count_G"] == 4
    assert s4["Count_C"] == 4
    assert s4["Length"] == 8
    assert s4["GC_Content_Pct"] == 100.0

    # 2. Test Model Training (Decision Tree & Random Forest)
    X = df[FEATURE_COLS]
    y = df["Group"]

    dt = DecisionTreeClassifier(random_state=42)
    dt.fit(X, y)
    assert dt.score(X, y) == 1.0

    rf = RandomForestClassifier(n_estimators=10, random_state=42)
    rf.fit(X, y)
    assert rf.score(X, y) == 1.0

    # 3. Test Unknown Query: ATGCGCGATC
    query = "ATGCGCGATC"
    val, _ = validate_dna(query)
    assert val is True

    q_feat = extract_features(query)
    q_vec = pd.DataFrame([q_feat])[FEATURE_COLS]
    pred_dt = dt.predict(q_vec)[0]
    pred_rf = rf.predict(q_vec)[0]

    print(f"\nQuery: {query}")
    print(f"Extracted Features: {q_feat}")
    print(f"Decision Tree Prediction: {pred_dt}")
    print(f"Random Forest Prediction: {pred_rf}")
    print(f"Random Forest Probabilities: {rf.predict_proba(q_vec)[0]}")
    print("\nAll pipeline tests passed successfully!")

if __name__ == "__main__":
    test_pipeline()
