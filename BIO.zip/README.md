# Predict the Genome Pattern: AI/ML-based Classification of DNA Sequences 🧬

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://streamlit.io/)
[![Python 3.9+](https://img.shields.io/badge/Python-3.9%2B-blue.svg)](https://www.python.org/)
[![Scikit-Learn](https://img.shields.io/badge/scikit--learn-1.3%2B-orange.svg)](https://scikit-learn.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

An end-to-end, production-ready Streamlit web application developed for the academic assignment **"Predict the Genome Pattern: AI/ML-based classification of DNA sequences"**. 

This application demonstrates the transformation of raw categorical genomic strings into numeric physicochemical feature vectors, trains interpretable tree-based and ensemble classifiers (Random Forest, Decision Tree), evaluates model performance diagnostics, and performs real-time classification of novel unknown DNA sequences with confidence probabilities.

---

## 📑 Table of Contents
1. [Assignment Objectives & Core Features](#-assignment-objectives--core-features)
2. [Dataset Overview](#-dataset-overview)
3. [The 6 Core Extracted Features](#-the-6-core-extracted-features)
4. [Machine Learning Workflow](#-machine-learning-workflow)
5. [Interactive Unknown Sequence Prediction](#-interactive-unknown-sequence-prediction)
6. [Critical Academic Discussion & Report Insights](#-critical-academic-discussion--report-insights)
7. [Installation & Local Execution](#-installation--local-execution)
8. [Deploying to Streamlit Community Cloud](#-deploying-to-streamlit-community-cloud)
9. [Project Structure](#-project-structure)

---

## 🎯 Assignment Objectives & Core Features

- **Automated Feature Engineering:** Converts raw DNA nucleotide strings (`A, T, G, C`) into 6 mathematical and biochemical descriptor features.
- **Interactive Dataset Explorer:** View, filter, or dynamically edit the assignment sequences (`S1` to `S4`) and toggle augmented biological benchmarks.
- **Model Training & Diagnostics:** Trains Scikit-Learn `RandomForestClassifier` or `DecisionTreeClassifier` with interactive hyperparameter tuning, accuracy metrics, Gini feature importance charts, and confusion matrix heatmaps.
- **Real-Time Sequence Inference:** Classifies arbitrary unknown sequences (pre-filled with `ATGCGCGATC`), validates IUPAC characters, and visualizes prediction probabilities and comparative feature radar plots.
- **Academic Report Section:** Thorough academic discussion addressing:
  - *Most Useful Features & Biochemical Basis*
  - *Real-World Genomics Applications*
  - *Limitations of AI/ML in Genomics*

---

## 📊 Dataset Overview

The default assignment dataset comprises four synthetic DNA fragments categorized into two biological groups:

| Sequence ID | Sequence ($5' \to 3'$) | Group Label | Description |
|:---:|:---:|:---:|:---|
| **S1** | `ATGCGATC` | **Group A** | Balanced nucleotide composition ($50.0\%$ GC) |
| **S2** | `ATGCGTAC` | **Group A** | Balanced nucleotide composition ($50.0\%$ GC) |
| **S3** | `GCGCGTAT` | **Group B** | GC-enriched fragment ($62.5\%$ GC, $5$ G+C out of 8) |
| **S4** | `GCGCGCGC` | **Group B** | Extreme GC-saturated fragment ($100.0\%$ GC, $8$ G+C out of 8) |

---

## 🧪 The 6 Core Extracted Features

Machine learning algorithms require numeric tensor inputs rather than raw string representations. For each sequence $S$:

1. **Count of Adenine ($Count_A$):** Frequency of base $A$.
2. **Count of Thymine ($Count_T$):** Frequency of base $T$.
3. **Count of Guanine ($Count_G$):** Frequency of base $G$.
4. **Count of Cytosine ($Count_C$):** Frequency of base $C$.
5. **Sequence Length ($L$):** Total number of nucleotides:
   $$L = Count_A + Count_T + Count_G + Count_C$$
6. **GC Content Percentage ($GC\%$):** Ratio of thermostable Guanine-Cytosine pairs (forming 3 hydrogen bonds) to total sequence length:
   $$GC\% = \left( \frac{Count_G + Count_C}{L} \right) \times 100$$

---

## 🤖 Machine Learning Workflow

1. **Preprocessing & Sanitization:** Strips whitespace, converts strings to uppercase, and validates that all characters belong to the canonical alphabet $\{A, C, G, T\}$.
2. **Feature Matrix Construction:** Constructs $X \in \mathbb{R}^{N \times 6}$ and label vector $y \in \{\text{Group A}, \text{Group B}\}$.
3. **Supervised Training:**
   - **Decision Tree Classifier:** Finds optimal axis-aligned decision thresholds (e.g., $GC\% \le 56.25\% \implies \text{Group A}$, else $\text{Group B}$).
   - **Random Forest Classifier:** A bootstrap ensemble of decision trees with feature sub-sampling to compute Gini importances.
4. **Performance Evaluation:** Computes training accuracy ($100\%$ on 4-sequence dataset), precision, recall, F1-score, and visualizes the confusion matrix.

---

## 🔮 Interactive Unknown Sequence Prediction

The web app includes an inference panel where users can test novel DNA sequences:
- **Default Sequence:** `ATGCGCGATC`
  - $L = 10$, $Count_A = 2$, $Count_T = 2$, $Count_G = 3$, $Count_C = 3$
  - $GC\% = \frac{3 + 3}{10} \times 100 = 60.0\%$
  - **Model Prediction:** Classified with associated group confidence probability.

---

## 📑 Critical Academic Discussion & Report Insights

### 1. Most Useful Features & Biochemical Basis
- **GC Content (%)** provides the dominant discriminatory boundary between Group A (mean $50.0\%$) and Group B (mean $81.25\%$).
- **Biochemical Foundation:** Guanine and Cytosine form **three hydrogen bonds** ($G \equiv C$), whereas Adenine and Thymine form only **two hydrogen bonds** ($A = T$). High GC content confers significantly increased thermal denaturation stability (elevated melting temperature $T_m$) and conformational rigidity.

### 2. Real-World Genomics Applications
- **Taxonomic & Pathogen Classification:** Distinguishing high-GC bacteria (*Actinobacteria*, e.g., *M. tuberculosis* $\sim 65\%$ GC) from low-GC bacteria (*Firmicutes*, e.g., *S. aureus* $\sim 33\%$ GC).
- **Metagenomic Binning:** Clustering environmental DNA reads into taxonomic groups without prior reference genomes.
- **Viral Host Adaptation:** Detecting codon and compositional biases reflecting viral-host co-evolution.
- **CpG Island Detection & Oncology:** Identifying promoter hypermethylation in tumor suppressor genes.

### 3. Limitations of AI/ML in Genomics
- **Out-of-Distribution (OOD) Sequences:** Models fail when encountering novel genomic variants or synthetic biology sequences outside the training domain.
- **Small-Sample Overfitting:** $N=4$ sequences leads to perfect empirical training accuracy through memorization rather than robust statistical generalizability.
- **"Bag of Nucleotides" Limitation:** Count and GC% features ignore **sequence order and spatial motifs**. Sequences with identical counts have vastly different biological functions, reading frames, and secondary structures. (Production genomics addresses this using $k$-mers, 1D CNNs, or Transformer foundation models like DNABERT).
- **Biological Noise & Sequencing Errors:** PCR amplification GC-bias and sequencer error profiles (Illumina substitutions, Nanopore indels).

---

## 💻 Installation & Local Execution

### Prerequisites
- Python 3.9, 3.10, 3.11, 3.12, 3.13, or 3.14
- `pip` package manager

### Steps
1. **Clone or navigate to the repository directory:**
   ```bash
   cd genome-pattern-classifier
   ```

2. **(Optional) Create a virtual environment:**
   ```bash
   python -m venv venv
   # Windows:
   .\venv\Scripts\activate
   # Linux / macOS:
   source venv/bin/activate
   ```

3. **Install required packages:**
   ```bash
   pip install -r requirements.txt
   ```

4. **Launch the Streamlit web application:**
   ```bash
   streamlit run app.py
   ```

5. Open your browser and navigate to `http://localhost:8501`.

---

## 🚀 Deploying to Streamlit Community Cloud

This project is 100% deployment-ready for [Streamlit Community Cloud](https://streamlit.io/cloud):

1. Push this repository to GitHub.
2. Log in to [Streamlit Community Cloud](https://share.streamlit.io/).
3. Click **"New App"**.
4. Select your GitHub repository, branch (`main`), and set the main file path to `app.py`.
5. Click **"Deploy"**. The platform will automatically install dependencies from `requirements.txt` and launch the live app.

---

## 📂 Project Structure

```text
genome-pattern-classifier/
├── .streamlit/
│   └── config.toml          # Custom modern UI styling & server configuration
├── app.py                   # Main Streamlit application with all tabs & logic
├── requirements.txt         # Production dependencies for cloud deployment
└── README.md                # Academic report, documentation, and deployment guide
```
